import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred,{
    'databaseURL' : "https://faceattendancesystem-1cf6e-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')
data = {
    "Ashrita Lahon" : {
        "name" : "Ashrita Lahon",
        "Roll No" : 220710007015,
        "total_attendance" : 6,
        "last_attendance_time" : "2024-10-11 00:54:34",
        "Starting year" : "2022"
    },
    "Anwesha Changkakoti" : {
        "name" : "Anwesha Changkakoty",
        "Roll No" : 220710007011,
        "total_attendance" : 5,
        "last_attendance_time" : "2024-10-11 00:54:34",
         "Starting year" : "2022"
    },
    "Sampriti Kalita" : {
        "name" : "Sampriti Kalita",
        "Roll No" : 220710007051,
        "total_attendance" : 9,
        "last_attendance_time" : "2024-10-11 00:54:34",
         "Starting year" : "2022"
    }


    #Store the rest students data in same manner
}
for key,value in data.items():
    ref.child(key).set(value)